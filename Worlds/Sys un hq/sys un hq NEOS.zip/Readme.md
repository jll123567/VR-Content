# "Sys un hq" For NEOS

## What's in here

Assets used to make this world.

## Did you make everything here.
Yes.

## Can I use these assets for my own projects.
Yep! All my assets are [CC0(Public Domain)](https://creativecommons.org/publicdomain/zero/1.0/).